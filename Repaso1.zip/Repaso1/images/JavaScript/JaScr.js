
function validar(){

    var usuario = document.getElementById("usuario").value;
    var contrasena = document.getElementById("pass").value;

    if (usuario == "LauraSL" && contrasena == "4983" ){
        alert("Bienvenida Laura Lopez, ya puedes realizar tus pedidos.");
    }else if(usuario == "LuisFS" && contrasena=="5092"){
        alert("Bienvenido Luis Suarez, ya puedes realizar tus pedidos.");
    }else if(usuario == "AnaMO" && contrasena=="9472"){
        alert("Bienvenida Ana Osorio, ya puedes realizar tus pedidos.");
    }else if(usuario == "AndresFR" && contrasena=="2037"){
        alert("Bienvenido Andrés Ruiz, ya puedes realizar tus pedidos.");
    }else if(usuario == "ManuelaP" && contrasena=="2158"){
        alert("Bienvenida Manuela Perez, ya puedes realizar tus pedidos.");
    }else if(usuario == "JorgeEC" && contrasena=="8316"){
        alert("Bienvenido Jorge Cruz, ya puedes realizar tus pedidos.");
    }
    else
    {
        alert("Verifica tus datos");
    }
}


/* Escenarios de las imagenes que van dentro de las imagenes.  */


function mostrar9() {
    var x = document.getElementById('imagen9');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}


function mostrar8() {
    var x = document.getElementById('imagen8');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}


function mostrar7() {
    var x = document.getElementById('imagen7');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}

function mostrar6() {
    var x = document.getElementById('imagen6');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}


function mostrar5() {
    var x = document.getElementById('imagen5');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}
function mostrar4() {
    var x = document.getElementById('imagen4');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}

function mostrar3() {
    var x = document.getElementById('imagen3');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}

function mostrar2() {
    var x = document.getElementById('imagen2');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}



function mostrar1() {
    var x = document.getElementById('imagen1');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}


function mostrarini1() {
    var x = document.getElementById('ini1');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}


function mostrarContac() {
    var x = document.getElementById('contac');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}






